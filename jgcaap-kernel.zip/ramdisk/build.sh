./unpackimg.sh boot.img
rm split_img/boot.img-dtb
rm split_img/boot.img-zImage
dtbToolCM -2 -o /home/jgcaap/oneplus/ramdisk/split_img/boot.img-dtb -s 2048 -p /home/jgcaap/msm8974/scripts/dtc/ /home/jgcaap/msm8974/arch/arm/boot/
cp /home/jgcaap/msm8974/arch/arm/boot/zImage /home/jgcaap/oneplus/ramdisk/split_img/boot.img-zImage
echo "Getting build information..."
cd split_img
kernel=`ls *-zImage`;               echo "kernel = $kernel";
if [ "$args" = "--original" ]; then
  ramdisk=`ls *-ramdisk.cpio*`;     echo "ramdisk = $ramdisk";
  ramdisk="split_img/$ramdisk";
else
  ramdisk="ramdisk-new.cpio.$compext";
fi;
cmdline=`cat *-cmdline`;            echo "cmdline = $cmdline";
board=`cat *-board`;                echo "board = $board";
base=`cat *-base`;                  echo "base = $base";
pagesize=`cat *-pagesize`;          echo "pagesize = $pagesize";
kerneloff=`cat *-kerneloff`;        echo "kernel_offset = $kerneloff";
ramdiskoff=`cat *-ramdiskoff`;      echo "ramdisk_offset = $ramdiskoff";
tagsoff=`cat *-tagsoff`;            echo "tags_offset = $tagsoff";
if [ -f *-second ]; then
  second=`ls *-second`;             echo "second = $second";  
  second="--second split_img/$second";
  secondoff=`cat *-secondoff`;      echo "second_offset = $secondoff";
  secondoff="--second_offset $secondoff";
fi;
if [ -f *-dtb ]; then
  dtb=`ls *-dtb`;                   echo "dtb = $dtb";
  dtb="--dt split_img/$dtb";
fi;
cd ..;

echo " ";
echo "Building image...";
echo " ";
mkbootimg --kernel "split_img/$kernel" --ramdisk "$ramdisk" $second --cmdline "$cmdline" --board "$board" --base $base --pagesize $pagesize --kernel_offset $kerneloff --ramdisk_offset $ramdiskoff $secondoff --tags_offset $tagsoff $dtb -o image-new.img;
echo "image-new.img ready"
cd ..
./repackimg.sh
echo "making zip file"
cp ../ramdisk/image-new.img zip/boot.img
cd zip/
zip -r9 jgcaap-kernel.zip * -x jgcaap-kernel.zip
echo "flash zip ready"
